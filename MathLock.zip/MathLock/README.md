# 🔒 MathLock — Smart Math Challenge Screen Time Controller

An Android app that interrupts your child's phone use with math challenges they must solve (or wait out) before returning to what they were doing.

---

## 📱 How It Works

1. **MathLock runs silently in the background** as a foreground service
2. **Every N minutes** (configurable), a full-screen math challenge appears
3. The challenge **cannot be dismissed** until:
   - The child solves the math problem correctly, OR  
   - The timeout expires (configurable, default 5 minutes)
4. **Admin settings** are PIN-protected so only the parent can change them

---

## ✨ Features

| Feature | Details |
|---|---|
| Full-screen challenge overlay | Blocks the current app, back button blocked |
| Countdown timer | Visible progress bar + mm:ss countdown |
| Auto-dismiss | Screen unlocks after configurable timeout |
| "Must solve" mode | Admin can force solve-only, no auto-dismiss |
| Wrong attempt limit | Optional cap on wrong guesses |
| 10 built-in questions | Easy/Medium/Hard across arithmetic topics |
| Admin PIN protection | Default PIN: **1234** — change immediately! |
| Add/Edit/Delete questions | Full CRUD for custom math questions |
| Per-question difficulty & toggle | Enable/disable individual questions |
| Survives reboot | BroadcastReceiver restarts service on boot |
| Shake animation on wrong answers | Visual feedback |
| Encouragement messages | Friendly UX for kids |

---

## 🚀 Setup Instructions

### Prerequisites
- Android Studio (Hedgehog 2023.1 or later)
- Android SDK 26+ (Android 8.0 Oreo minimum)
- A physical Android device recommended (emulator works but overlay tests are better on device)

### Build Steps

1. **Clone / copy** the project folder into Android Studio:
   ```
   File → Open → select the MathLock folder
   ```

2. **Sync Gradle** — Android Studio will prompt you. Click "Sync Now".

3. **Build the APK:**
   ```
   Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```
   Or run directly on a connected device with **Run → Run 'app'**

4. **Install on your child's device** via ADB or share the APK file.

### First-Time Setup on Child's Device

1. Open **MathLock**
2. Grant the **"Display over other apps"** permission when prompted  
   *(Settings → Apps → MathLock → Display over other apps → Allow)*
3. The app starts running — green status screen shows
4. Tap **⚙️ Admin Settings**
5. Enter PIN: **`1234`** (default)
6. **IMMEDIATELY change the PIN** in the admin panel!
7. Configure your desired settings and save

---

## ⚙️ Admin Configuration Options

Access via: Main screen → Admin Settings → enter PIN

| Setting | Default | Description |
|---|---|---|
| Enable MathLock | ON | Master toggle — disables all challenges when off |
| Timeout (minutes) | 5 | How long before challenge auto-dismisses |
| Challenge interval (mins) | 30 | How often a challenge appears |
| Must solve to dismiss | OFF | If ON, timeout doesn't help — must solve |
| Max wrong attempts | 0 (unlimited) | Lock out input after N wrong answers |
| Admin PIN | 1234 | **Change this!** |

### Managing Questions

In the Admin Panel, scroll down to **Math Questions**:
- **Toggle** individual questions on/off without deleting
- **Edit** question text, answer, or difficulty
- **Delete** questions you don't want
- **Add** your own custom questions

> **Tip:** Questions can be anything with a text answer — not just numbers!  
> e.g., "Spell the answer to 4+4" → Answer: "eight"

---

## 🏗️ Architecture Overview

```
MathLock/
├── activities/
│   ├── MainActivity.java          # Kid-facing home screen
│   ├── AdminLoginActivity.java    # PIN entry screen
│   ├── AdminPanelActivity.java    # Full admin configuration
│   ├── QuestionEditorActivity.java # Add/edit questions
│   └── MathChallengeActivity.java # THE OVERLAY (full-screen lock)
├── services/
│   ├── MathLockService.java       # Foreground service + alarm scheduler
│   ├── AlarmReceiver.java         # Fires when alarm triggers challenge
│   └── BootReceiver.java          # Restarts after device reboot
├── models/
│   ├── MathQuestion.java          # Question data model
│   └── AppSettings.java           # Settings data model
└── utils/
    └── DataManager.java           # SharedPreferences persistence (Gson)
```

**Data storage:** All data stored in `SharedPreferences` with Gson serialization — no database needed, works offline, survives updates.

**Scheduling:** Uses `AlarmManager.setExactAndAllowWhileIdle()` for reliable background scheduling even in Doze mode.

---

## 🔧 Permissions Explained

| Permission | Why needed |
|---|---|
| `SYSTEM_ALERT_WINDOW` | Show math challenge over other apps |
| `RECEIVE_BOOT_COMPLETED` | Restart service after phone reboot |
| `FOREGROUND_SERVICE` | Keep service running in background |
| `USE_EXACT_ALARM` | Reliable challenge timing |
| `WAKE_LOCK` | Wake screen for challenges |

---

## 📝 Adding Custom Questions — Examples

| Question | Answer | Difficulty |
|---|---|---|
| What is 6 × 9? | 54 | Easy |
| What is 15% of 200? | 30 | Medium |
| What is the square root of 169? | 13 | Medium |
| What is 2 to the power of 10? | 1024 | Hard |
| How many seconds in an hour? | 3600 | Easy |
| What is 1000 minus 437? | 563 | Medium |

---

## ⚠️ Known Limitations

- **Back button is blocked** during challenge — this is by design
- On Android 12+, some manufacturers (Xiaomi/MIUI, OnePlus) have aggressive battery optimization that may delay challenges. Go to Settings → Battery → App launch → set MathLock to "Manage manually" and enable all three options.
- The overlay cannot replace the **native lock screen** — if the device is locked, the challenge shows when it unlocks
- **Do not enable "Must solve to dismiss"** unless your child can reliably solve all your enabled questions

---

## 🛡️ Security Notes

- The admin PIN is stored in `SharedPreferences` (device local, not transmitted)  
- If your child finds and uninstalls the app: consider pairing with a device management (MDM) profile to prevent uninstall
- For stronger enforcement, combine with Android's **Digital Wellbeing** or a launcher lock

---

## 📦 Dependencies

```gradle
implementation 'androidx.appcompat:appcompat:1.6.1'
implementation 'com.google.android.material:material:1.11.0'
implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
implementation 'androidx.recyclerview:recyclerview:1.3.2'
implementation 'com.google.code.gson:gson:2.10.1'
```

No third-party SDKs, no tracking, no internet permission required.
