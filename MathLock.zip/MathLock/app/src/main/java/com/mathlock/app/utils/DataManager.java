package com.mathlock.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.models.MathQuestion;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DataManager {

    private static final String PREFS_NAME = "MathLockPrefs";
    private static final String KEY_SETTINGS = "settings";
    private static final String KEY_QUESTIONS = "questions";

    private static DataManager instance;
    private final SharedPreferences prefs;
    private final Gson gson;

    private DataManager(Context context) {
        prefs = context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
        ensureDefaultsExist();
    }

    public static DataManager getInstance(Context context) {
        if (instance == null) {
            instance = new DataManager(context);
        }
        return instance;
    }

    // ─── Settings ────────────────────────────────────────────────────────────

    public AppSettings getSettings() {
        String json = prefs.getString(KEY_SETTINGS, null);
        if (json == null) return new AppSettings();
        return gson.fromJson(json, AppSettings.class);
    }

    public void saveSettings(AppSettings settings) {
        prefs.edit().putString(KEY_SETTINGS, gson.toJson(settings)).apply();
    }

    // ─── Questions ───────────────────────────────────────────────────────────

    public List<MathQuestion> getQuestions() {
        String json = prefs.getString(KEY_QUESTIONS, null);
        if (json == null) return new ArrayList<>();
        Type type = new TypeToken<List<MathQuestion>>() {}.getType();
        return gson.fromJson(json, type);
    }

    public void saveQuestions(List<MathQuestion> questions) {
        prefs.edit().putString(KEY_QUESTIONS, gson.toJson(questions)).apply();
    }

    public void addQuestion(MathQuestion question) {
        if (question.getId() == null) {
            question.setId(UUID.randomUUID().toString());
        }
        List<MathQuestion> questions = getQuestions();
        questions.add(question);
        saveQuestions(questions);
    }

    public void updateQuestion(MathQuestion updated) {
        List<MathQuestion> questions = getQuestions();
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).getId().equals(updated.getId())) {
                questions.set(i, updated);
                break;
            }
        }
        saveQuestions(questions);
    }

    public void deleteQuestion(String id) {
        List<MathQuestion> questions = getQuestions();
        questions.removeIf(q -> q.getId().equals(id));
        saveQuestions(questions);
    }

    public MathQuestion getRandomEnabledQuestion() {
        List<MathQuestion> all = getQuestions();
        List<MathQuestion> enabled = new ArrayList<>();
        for (MathQuestion q : all) {
            if (q.isEnabled()) enabled.add(q);
        }
        if (enabled.isEmpty()) return null;
        int idx = (int) (Math.random() * enabled.size());
        return enabled.get(idx);
    }

    // ─── Seed default questions ───────────────────────────────────────────────

    private void ensureDefaultsExist() {
        if (prefs.getString(KEY_QUESTIONS, null) == null) {
            List<MathQuestion> defaults = new ArrayList<>();
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 7 × 8?", "56", "easy"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 144 ÷ 12?", "12", "easy"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 15 + 27?", "42", "easy"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 9²?", "81", "medium"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 13 × 7?", "91", "medium"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is √256?", "16", "medium"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 25% of 360?", "90", "medium"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 17 × 13?", "221", "hard"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 2⁸?", "256", "hard"));
            defaults.add(new MathQuestion(UUID.randomUUID().toString(), "What is 1000 ÷ 8?", "125", "hard"));
            saveQuestions(defaults);
        }
        if (prefs.getString(KEY_SETTINGS, null) == null) {
            saveSettings(new AppSettings());
        }
    }
}
