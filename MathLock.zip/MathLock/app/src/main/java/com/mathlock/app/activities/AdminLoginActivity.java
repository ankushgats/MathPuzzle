package com.mathlock.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.mathlock.app.R;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.utils.DataManager;

public class AdminLoginActivity extends AppCompatActivity {

    private EditText etPin;
    private TextView tvError;
    private int failedAttempts = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        etPin = findViewById(R.id.etPin);
        tvError = findViewById(R.id.tvError);
        Button btnLogin = findViewById(R.id.btnLogin);
        TextView tvCancel = findViewById(R.id.tvCancel);

        btnLogin.setOnClickListener(v -> attemptLogin());
        tvCancel.setOnClickListener(v -> finish());
    }

    private void attemptLogin() {
        String entered = etPin.getText().toString().trim();
        AppSettings settings = DataManager.getInstance(this).getSettings();

        if (entered.equals(settings.getAdminPin())) {
            startActivity(new Intent(this, AdminPanelActivity.class));
            finish();
        } else {
            failedAttempts++;
            etPin.setText("");
            etPin.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
            tvError.setText("Incorrect PIN. Attempt " + failedAttempts);
            tvError.setVisibility(android.view.View.VISIBLE);
        }
    }
}
