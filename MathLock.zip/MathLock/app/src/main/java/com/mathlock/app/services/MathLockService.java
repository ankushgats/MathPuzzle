package com.mathlock.app.services;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.SystemClock;
import androidx.core.app.NotificationCompat;

import com.mathlock.app.R;
import com.mathlock.app.activities.MainActivity;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.utils.DataManager;

public class MathLockService extends Service {

    public static final String CHANNEL_ID = "MathLockChannel";
    public static final String ACTION_TRIGGER_CHALLENGE = "com.mathlock.TRIGGER_CHALLENGE";
    public static final String ACTION_START = "com.mathlock.START";
    public static final String ACTION_STOP = "com.mathlock.STOP";
    public static final String ACTION_RESCHEDULE = "com.mathlock.RESCHEDULE";

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        startForeground(1, buildNotification());

        if (ACTION_STOP.equals(action)) {
            cancelAlarm();
            stopSelf();
            return START_NOT_STICKY;
        }

        // START or RESCHEDULE — re-schedule next alarm
        scheduleNextChallenge();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    private void scheduleNextChallenge() {
        AppSettings settings = DataManager.getInstance(this).getSettings();
        if (!settings.isAppEnabled()) {
            cancelAlarm();
            return;
        }

        long intervalMs = settings.getChallengeIntervalMinutes() * 60 * 1000L;
        long triggerAt = SystemClock.elapsedRealtime() + intervalMs;

        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = getChallengeIntent();

        if (am != null) {
            am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pi);
        }
    }

    private void cancelAlarm() {
        AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (am != null) {
            am.cancel(getChallengeIntent());
        }
    }

    private PendingIntent getChallengeIntent() {
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.setAction(ACTION_TRIGGER_CHALLENGE);
        return PendingIntent.getBroadcast(this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private Notification buildNotification() {
        Intent openIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingOpen = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("MathLock Active")
                .setContentText("Math challenges are enabled")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pendingOpen)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_MIN)
                .build();
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "MathLock Service",
                NotificationManager.IMPORTANCE_MIN);
        channel.setDescription("Keeps MathLock running in background");
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.createNotificationChannel(channel);
    }

    // ─── Static helpers ───────────────────────────────────────────────────────

    public static void start(Context context) {
        Intent intent = new Intent(context, MathLockService.class);
        intent.setAction(ACTION_START);
        context.startForegroundService(intent);
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, MathLockService.class);
        intent.setAction(ACTION_STOP);
        context.startForegroundService(intent);
    }

    public static void reschedule(Context context) {
        Intent intent = new Intent(context, MathLockService.class);
        intent.setAction(ACTION_RESCHEDULE);
        context.startForegroundService(intent);
    }
}
