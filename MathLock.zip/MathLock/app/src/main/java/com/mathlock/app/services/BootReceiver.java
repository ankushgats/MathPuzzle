package com.mathlock.app.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.mathlock.app.models.AppSettings;
import com.mathlock.app.utils.DataManager;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            AppSettings settings = DataManager.getInstance(context).getSettings();
            if (settings.isAppEnabled()) {
                MathLockService.start(context);
            }
        }
    }
}
