package com.mathlock.app.models;

public class AppSettings {
    private boolean appEnabled;
    private int timeoutMinutes;          // minutes before auto-dismiss
    private int challengeIntervalMinutes; // how often to show challenge
    private String adminPin;
    private boolean requireSolveToClose; // if false, can always close after timeout
    private int maxWrongAttempts;        // 0 = unlimited

    public AppSettings() {
        // Defaults
        this.appEnabled = true;
        this.timeoutMinutes = 5;
        this.challengeIntervalMinutes = 30;
        this.adminPin = "1234";
        this.requireSolveToClose = false;
        this.maxWrongAttempts = 0;
    }

    public boolean isAppEnabled() { return appEnabled; }
    public void setAppEnabled(boolean appEnabled) { this.appEnabled = appEnabled; }

    public int getTimeoutMinutes() { return timeoutMinutes; }
    public void setTimeoutMinutes(int timeoutMinutes) { this.timeoutMinutes = timeoutMinutes; }

    public int getChallengeIntervalMinutes() { return challengeIntervalMinutes; }
    public void setChallengeIntervalMinutes(int challengeIntervalMinutes) { this.challengeIntervalMinutes = challengeIntervalMinutes; }

    public String getAdminPin() { return adminPin; }
    public void setAdminPin(String adminPin) { this.adminPin = adminPin; }

    public boolean isRequireSolveToClose() { return requireSolveToClose; }
    public void setRequireSolveToClose(boolean requireSolveToClose) { this.requireSolveToClose = requireSolveToClose; }

    public int getMaxWrongAttempts() { return maxWrongAttempts; }
    public void setMaxWrongAttempts(int maxWrongAttempts) { this.maxWrongAttempts = maxWrongAttempts; }
}
