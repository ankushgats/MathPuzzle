package com.mathlock.app.activities;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.mathlock.app.R;
import com.mathlock.app.models.MathQuestion;
import com.mathlock.app.utils.DataManager;
import java.util.UUID;

public class QuestionEditorActivity extends AppCompatActivity {

    public static final String EXTRA_QUESTION_ID = "question_id";

    private EditText etQuestion, etAnswer;
    private Spinner spinnerDifficulty;
    private DataManager dataManager;
    private MathQuestion editingQuestion; // null = new question

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_editor);

        dataManager = DataManager.getInstance(this);

        etQuestion = findViewById(R.id.etQuestion);
        etAnswer = findViewById(R.id.etAnswer);
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty);
        Button btnSave = findViewById(R.id.btnSave);
        Button btnCancel = findViewById(R.id.btnCancel);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
            this, R.array.difficulty_levels, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDifficulty.setAdapter(adapter);

        // Load existing question if editing
        String questionId = getIntent().getStringExtra(EXTRA_QUESTION_ID);
        if (questionId != null) {
            for (MathQuestion q : dataManager.getQuestions()) {
                if (q.getId().equals(questionId)) {
                    editingQuestion = q;
                    break;
                }
            }
        }

        if (editingQuestion != null) {
            etQuestion.setText(editingQuestion.getQuestionText());
            etAnswer.setText(editingQuestion.getAnswer());
            String diff = editingQuestion.getDifficulty();
            String[] levels = getResources().getStringArray(R.array.difficulty_levels);
            for (int i = 0; i < levels.length; i++) {
                if (levels[i].toLowerCase().equals(diff)) {
                    spinnerDifficulty.setSelection(i);
                    break;
                }
            }
        }

        btnSave.setOnClickListener(v -> save());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void save() {
        String questionText = etQuestion.getText().toString().trim();
        String answer = etAnswer.getText().toString().trim();
        String difficulty = spinnerDifficulty.getSelectedItem().toString().toLowerCase();

        if (questionText.isEmpty()) {
            etQuestion.setError("Question is required");
            return;
        }
        if (answer.isEmpty()) {
            etAnswer.setError("Answer is required");
            return;
        }

        if (editingQuestion == null) {
            MathQuestion q = new MathQuestion(
                UUID.randomUUID().toString(), questionText, answer, difficulty);
            dataManager.addQuestion(q);
            Toast.makeText(this, "Question added ✅", Toast.LENGTH_SHORT).show();
        } else {
            editingQuestion.setQuestionText(questionText);
            editingQuestion.setAnswer(answer);
            editingQuestion.setDifficulty(difficulty);
            dataManager.updateQuestion(editingQuestion);
            Toast.makeText(this, "Question updated ✅", Toast.LENGTH_SHORT).show();
        }
        finish();
    }
}
