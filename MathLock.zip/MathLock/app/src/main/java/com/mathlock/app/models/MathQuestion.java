package com.mathlock.app.models;

public class MathQuestion {
    private String id;
    private String questionText;
    private String answer;
    private String difficulty; // "easy", "medium", "hard"
    private boolean enabled;

    public MathQuestion() {}

    public MathQuestion(String id, String questionText, String answer, String difficulty) {
        this.id = id;
        this.questionText = questionText;
        this.answer = answer;
        this.difficulty = difficulty;
        this.enabled = true;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }

    public String getAnswer() { return answer; }
    public void setAnswer(String answer) { this.answer = answer; }

    public String getDifficulty() { return difficulty; }
    public void setDifficulty(String difficulty) { this.difficulty = difficulty; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
