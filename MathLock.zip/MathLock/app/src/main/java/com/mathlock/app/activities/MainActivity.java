package com.mathlock.app.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.mathlock.app.R;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.services.MathLockService;
import com.mathlock.app.utils.DataManager;

public class MainActivity extends AppCompatActivity {

    private TextView tvStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus = findViewById(R.id.tvStatus);
        Button btnAdmin = findViewById(R.id.btnAdmin);

        btnAdmin.setOnClickListener(v ->
            startActivity(new Intent(this, AdminLoginActivity.class)));

        checkPermissions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private void updateStatus() {
        AppSettings settings = DataManager.getInstance(this).getSettings();
        if (settings.isAppEnabled()) {
            tvStatus.setText("🟢 MathLock is ACTIVE\nChallenges every " +
                settings.getChallengeIntervalMinutes() + " minutes");
            tvStatus.setTextColor(getColor(R.color.green));
            MathLockService.start(this);
        } else {
            tvStatus.setText("🔴 MathLock is DISABLED\nAdmin turned it off");
            tvStatus.setTextColor(getColor(R.color.red));
        }
    }

    private void checkPermissions() {
        // Check overlay permission (needed to show over other apps)
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                .setTitle("Permission Required")
                .setMessage("MathLock needs permission to display over other apps so it can show math challenges. Please grant this permission.")
                .setPositiveButton("Grant Permission", (d, w) -> {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                })
                .setNegativeButton("Cancel", (d, w) ->
                    Toast.makeText(this, "Permission needed for full functionality", Toast.LENGTH_LONG).show())
                .setCancelable(false)
                .show();
        }
    }
}
