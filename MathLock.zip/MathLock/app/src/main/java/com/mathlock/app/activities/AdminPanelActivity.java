package com.mathlock.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.mathlock.app.R;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.models.MathQuestion;
import com.mathlock.app.services.MathLockService;
import com.mathlock.app.utils.DataManager;

import java.util.List;

public class AdminPanelActivity extends AppCompatActivity {

    private DataManager dataManager;
    private AppSettings settings;
    private Switch switchEnabled;
    private EditText etTimeout, etInterval, etNewPin, etMaxAttempts;
    private Switch switchRequireSolve;
    private RecyclerView rvQuestions;
    private QuestionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_panel);

        dataManager = DataManager.getInstance(this);
        settings = dataManager.getSettings();

        bindViews();
        loadSettings();
        loadQuestions();
    }

    private void bindViews() {
        switchEnabled = findViewById(R.id.switchEnabled);
        etTimeout = findViewById(R.id.etTimeout);
        etInterval = findViewById(R.id.etInterval);
        etNewPin = findViewById(R.id.etNewPin);
        etMaxAttempts = findViewById(R.id.etMaxAttempts);
        switchRequireSolve = findViewById(R.id.switchRequireSolve);
        rvQuestions = findViewById(R.id.rvQuestions);
        Button btnSaveSettings = findViewById(R.id.btnSaveSettings);
        Button btnAddQuestion = findViewById(R.id.btnAddQuestion);
        Button btnTestChallenge = findViewById(R.id.btnTestChallenge);

        rvQuestions.setLayoutManager(new LinearLayoutManager(this));

        btnSaveSettings.setOnClickListener(v -> saveSettings());
        btnAddQuestion.setOnClickListener(v -> openQuestionEditor(null));
        btnTestChallenge.setOnClickListener(v -> testChallenge());
    }

    private void loadSettings() {
        switchEnabled.setChecked(settings.isAppEnabled());
        etTimeout.setText(String.valueOf(settings.getTimeoutMinutes()));
        etInterval.setText(String.valueOf(settings.getChallengeIntervalMinutes()));
        etMaxAttempts.setText(String.valueOf(settings.getMaxWrongAttempts()));
        switchRequireSolve.setChecked(settings.isRequireSolveToClose());
    }

    private void loadQuestions() {
        List<MathQuestion> questions = dataManager.getQuestions();
        adapter = new QuestionAdapter(questions);
        rvQuestions.setAdapter(adapter);
    }

    private void saveSettings() {
        try {
            settings.setAppEnabled(switchEnabled.isChecked());
            settings.setTimeoutMinutes(Integer.parseInt(etTimeout.getText().toString().trim()));
            settings.setChallengeIntervalMinutes(Integer.parseInt(etInterval.getText().toString().trim()));
            settings.setMaxWrongAttempts(Integer.parseInt(etMaxAttempts.getText().toString().trim()));
            settings.setRequireSolveToClose(switchRequireSolve.isChecked());

            String newPin = etNewPin.getText().toString().trim();
            if (!newPin.isEmpty()) {
                if (newPin.length() < 4) {
                    Toast.makeText(this, "PIN must be at least 4 digits", Toast.LENGTH_SHORT).show();
                    return;
                }
                settings.setAdminPin(newPin);
                etNewPin.setText("");
            }

            dataManager.saveSettings(settings);

            // Restart / stop service based on toggle
            if (settings.isAppEnabled()) {
                MathLockService.reschedule(this);
            } else {
                MathLockService.stop(this);
            }

            Toast.makeText(this, "✅ Settings saved!", Toast.LENGTH_SHORT).show();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
        }
    }

    private void testChallenge() {
        MathQuestion q = dataManager.getRandomEnabledQuestion();
        if (q == null) {
            Toast.makeText(this, "No enabled questions found", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(this, MathChallengeActivity.class);
        intent.putExtra(MathChallengeActivity.EXTRA_QUESTION_ID, q.getId());
        startActivity(intent);
    }

    private void openQuestionEditor(MathQuestion question) {
        Intent intent = new Intent(this, QuestionEditorActivity.class);
        if (question != null) {
            intent.putExtra(QuestionEditorActivity.EXTRA_QUESTION_ID, question.getId());
        }
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadQuestions(); // refresh list after editing
    }

    // ─── Inner RecyclerView Adapter ───────────────────────────────────────────

    private class QuestionAdapter extends RecyclerView.Adapter<QuestionAdapter.VH> {

        private final List<MathQuestion> questions;

        QuestionAdapter(List<MathQuestion> questions) { this.questions = questions; }

        @Override
        public VH onCreateViewHolder(ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_question, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            MathQuestion q = questions.get(position);
            holder.tvQuestion.setText(q.getQuestionText());
            holder.tvAnswer.setText("Answer: " + q.getAnswer() + "  [" + q.getDifficulty() + "]");
            holder.switchEnabled.setChecked(q.isEnabled());

            holder.switchEnabled.setOnCheckedChangeListener((btn, checked) -> {
                q.setEnabled(checked);
                dataManager.updateQuestion(q);
            });

            holder.btnEdit.setOnClickListener(v -> openQuestionEditor(q));
            holder.btnDelete.setOnClickListener(v -> confirmDelete(q, position));
        }

        private void confirmDelete(MathQuestion q, int position) {
            new AlertDialog.Builder(AdminPanelActivity.this)
                .setTitle("Delete Question")
                .setMessage("Delete \"" + q.getQuestionText() + "\"?")
                .setPositiveButton("Delete", (d, w) -> {
                    dataManager.deleteQuestion(q.getId());
                    questions.remove(position);
                    notifyItemRemoved(position);
                })
                .setNegativeButton("Cancel", null)
                .show();
        }

        @Override
        public int getItemCount() { return questions.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvQuestion, tvAnswer;
            Switch switchEnabled;
            ImageButton btnEdit, btnDelete;

            VH(View v) {
                super(v);
                tvQuestion = v.findViewById(R.id.tvQuestion);
                tvAnswer = v.findViewById(R.id.tvAnswer);
                switchEnabled = v.findViewById(R.id.switchEnabled);
                btnEdit = v.findViewById(R.id.btnEdit);
                btnDelete = v.findViewById(R.id.btnDelete);
            }
        }
    }
}
