package com.mathlock.app.activities;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.mathlock.app.R;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.models.MathQuestion;
import com.mathlock.app.utils.DataManager;

public class MathChallengeActivity extends AppCompatActivity {

    public static final String EXTRA_QUESTION_ID = "question_id";

    private TextView tvQuestion, tvTimer, tvAttempts, tvEncouragement;
    private EditText etAnswer;
    private Button btnSubmit;
    private ProgressBar progressTimer;
    private ImageView ivResult;

    private MathQuestion currentQuestion;
    private AppSettings settings;
    private DataManager dataManager;
    private CountDownTimer countDownTimer;
    private int wrongAttempts = 0;
    private boolean dismissed = false;

    private static final String[] ENCOURAGEMENTS = {
        "You can do it! 🧠",
        "Think carefully...",
        "Almost there! 💪",
        "Math is your superpower!",
        "Take your time 🤔"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Make this show over the lock screen
        getWindow().addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
            WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
        );

        setContentView(R.layout.activity_math_challenge);

        dataManager = DataManager.getInstance(this);
        settings = dataManager.getSettings();

        bindViews();
        loadQuestion();
        startCountdown();
        setRandomEncouragement();
    }

    private void bindViews() {
        tvQuestion = findViewById(R.id.tvQuestion);
        tvTimer = findViewById(R.id.tvTimer);
        tvAttempts = findViewById(R.id.tvAttempts);
        tvEncouragement = findViewById(R.id.tvEncouragement);
        etAnswer = findViewById(R.id.etAnswer);
        btnSubmit = findViewById(R.id.btnSubmit);
        progressTimer = findViewById(R.id.progressTimer);
        ivResult = findViewById(R.id.ivResult);

        btnSubmit.setOnClickListener(v -> checkAnswer());

        etAnswer.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                checkAnswer();
                return true;
            }
            return false;
        });
    }

    private void loadQuestion() {
        String questionId = getIntent().getStringExtra(EXTRA_QUESTION_ID);
        if (questionId != null) {
            for (MathQuestion q : dataManager.getQuestions()) {
                if (q.getId().equals(questionId)) {
                    currentQuestion = q;
                    break;
                }
            }
        }
        if (currentQuestion == null) {
            currentQuestion = dataManager.getRandomEnabledQuestion();
        }
        if (currentQuestion == null) {
            // No questions — close
            dismiss(false);
            return;
        }
        tvQuestion.setText(currentQuestion.getQuestionText());
        updateDifficultyColor();
    }

    private void updateDifficultyColor() {
        if (currentQuestion == null) return;
        int color;
        switch (currentQuestion.getDifficulty()) {
            case "hard": color = Color.parseColor("#E53935"); break;
            case "medium": color = Color.parseColor("#FB8C00"); break;
            default: color = Color.parseColor("#43A047"); break;
        }
        tvQuestion.setTextColor(color);
    }

    private void startCountdown() {
        long totalMs = settings.getTimeoutMinutes() * 60 * 1000L;
        progressTimer.setMax((int) (totalMs / 1000));

        countDownTimer = new CountDownTimer(totalMs, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long secs = millisUntilFinished / 1000;
                long mins = secs / 60;
                secs = secs % 60;
                tvTimer.setText(String.format("%02d:%02d", mins, secs));
                progressTimer.setProgress((int) (millisUntilFinished / 1000));

                // Pulse the timer red in last 30 seconds
                if (millisUntilFinished < 30_000) {
                    tvTimer.setTextColor(Color.parseColor("#E53935"));
                }
            }

            @Override
            public void onFinish() {
                tvTimer.setText("00:00");
                progressTimer.setProgress(0);
                if (!settings.isRequireSolveToClose()) {
                    showTimeoutMessage();
                } else {
                    tvTimer.setText("Must solve!");
                    tvTimer.setTextColor(Color.parseColor("#E53935"));
                }
            }
        }.start();
    }

    private void checkAnswer() {
        String userAnswer = etAnswer.getText().toString().trim();
        if (userAnswer.isEmpty()) {
            etAnswer.setError("Please enter an answer");
            return;
        }

        if (userAnswer.equalsIgnoreCase(currentQuestion.getAnswer())) {
            onCorrectAnswer();
        } else {
            onWrongAnswer();
        }
    }

    private void onCorrectAnswer() {
        if (countDownTimer != null) countDownTimer.cancel();
        showResultIcon(true);
        etAnswer.setEnabled(false);
        btnSubmit.setEnabled(false);
        tvEncouragement.setText("🎉 Correct! Great job!");
        tvEncouragement.setTextColor(Color.parseColor("#43A047"));

        // Dismiss after short celebration delay
        tvQuestion.postDelayed(() -> dismiss(true), 1500);
    }

    private void onWrongAnswer() {
        wrongAttempts++;
        int maxAttempts = settings.getMaxWrongAttempts();

        etAnswer.setText("");
        etAnswer.startAnimation(AnimationUtils.loadAnimation(this, R.anim.shake));
        showResultIcon(false);

        if (maxAttempts > 0) {
            int remaining = maxAttempts - wrongAttempts;
            if (remaining <= 0) {
                tvAttempts.setText("No more attempts!");
                tvAttempts.setTextColor(Color.parseColor("#E53935"));
                etAnswer.setEnabled(false);
                btnSubmit.setEnabled(false);
                tvEncouragement.setText("Wait for the timer ⏱️");
            } else {
                tvAttempts.setText("Wrong! " + remaining + " attempt(s) left");
                tvAttempts.setTextColor(Color.parseColor("#E53935"));
            }
        } else {
            tvAttempts.setText("Wrong! Try again 🔄");
            tvAttempts.setTextColor(Color.parseColor("#FB8C00"));
        }
    }

    private void showResultIcon(boolean correct) {
        ivResult.setImageResource(correct ? R.drawable.ic_check : R.drawable.ic_close);
        ivResult.setColorFilter(correct
            ? Color.parseColor("#43A047")
            : Color.parseColor("#E53935"));
        ivResult.setVisibility(View.VISIBLE);
        ivResult.startAnimation(AnimationUtils.loadAnimation(this, R.anim.pop_in));

        ivResult.postDelayed(() -> ivResult.setVisibility(View.GONE), 1000);
    }

    private void showTimeoutMessage() {
        if (dismissed) return;
        tvEncouragement.setText("Time's up! Screen unlocked ⏱️");
        tvEncouragement.setTextColor(Color.parseColor("#FB8C00"));
        tvQuestion.postDelayed(() -> dismiss(false), 2000);
    }

    private void setRandomEncouragement() {
        int idx = (int) (Math.random() * ENCOURAGEMENTS.length);
        tvEncouragement.setText(ENCOURAGEMENTS[idx]);
    }

    private void dismiss(boolean solved) {
        dismissed = true;
        if (countDownTimer != null) countDownTimer.cancel();
        finish();
    }

    // ─── Block back/home/recents ──────────────────────────────────────────────

    @Override
    public void onBackPressed() {
        // Block back button while challenge is active
        Toast.makeText(this, "Solve the question first! 🔒", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_HOME || keyCode == KeyEvent.KEYCODE_APP_SWITCH) {
            return true; // Block
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Bring ourselves back if user tries to switch away
        if (!dismissed) {
            Intent intent = new Intent(this, MathChallengeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (countDownTimer != null) countDownTimer.cancel();
    }
}
