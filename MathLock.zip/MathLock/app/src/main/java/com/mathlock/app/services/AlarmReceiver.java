package com.mathlock.app.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.mathlock.app.activities.MathChallengeActivity;
import com.mathlock.app.models.AppSettings;
import com.mathlock.app.models.MathQuestion;
import com.mathlock.app.utils.DataManager;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        DataManager dm = DataManager.getInstance(context);
        AppSettings settings = dm.getSettings();

        if (!settings.isAppEnabled()) {
            return; // app is disabled by admin, do nothing
        }

        MathQuestion question = dm.getRandomEnabledQuestion();
        if (question == null) {
            // No questions configured — reschedule and bail
            MathLockService.reschedule(context);
            return;
        }

        // Launch the full-screen math challenge
        Intent challengeIntent = new Intent(context, MathChallengeActivity.class);
        challengeIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        challengeIntent.putExtra(MathChallengeActivity.EXTRA_QUESTION_ID, question.getId());
        context.startActivity(challengeIntent);

        // Reschedule the next alarm
        MathLockService.reschedule(context);
    }
}
